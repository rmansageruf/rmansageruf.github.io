import PageManager from '../PageManager';

export default class Errors404 extends PageManager {
  constructor() {
    super();
  }
}

