import PageManager from '../PageManager';

export default class Page extends PageManager {
    constructor() {
        super();
    }
}
