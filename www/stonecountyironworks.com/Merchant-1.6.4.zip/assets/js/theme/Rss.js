import PageManager from '../PageManager';

export default class RSS extends PageManager {
    constructor() {
        super();
    }
}

