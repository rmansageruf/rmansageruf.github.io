import PageManager from '../PageManager';

export default class BlogPost extends PageManager {
    constructor() {
        super();
    }
}
