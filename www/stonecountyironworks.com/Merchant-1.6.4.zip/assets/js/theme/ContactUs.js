import PageManager from '../PageManager';
import $ from 'jquery';

export default class ContactUs extends PageManager {
  constructor() {
    super();
  }
}
