import PageManager from '../PageManager';

export default class Subscribe extends PageManager {
    constructor() {
        super();
    }
}
