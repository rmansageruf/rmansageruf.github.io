# Merchant

**Development Owner:** Nic Oliver

Development Store URL: `http://nboliver.mybigcommerce.com`

### Installation

```
git clone git@bitbucket.org:pixelunion/merchant-bc.git
cd merchant-bc
jspm install
stencil init
stencil start
```
